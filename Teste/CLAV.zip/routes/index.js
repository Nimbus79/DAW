var express = require('express');
var router = express.Router();
var axios = require('axios')

/* GET home page. */

/*
//PARTE 1

// Exercício 2
axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/4')
  .then(resposta => console.log("Número de classes do nível 4: " + resposta.data.length))
  .catch(erro => console.log('Erro ao carregar dados.'))


// Exercício 1
questao1()

function questao1() {
  var desc = []
  var nivel3 = []
  axios.get('http://clav-test.di.uminho.pt/api/classes/c200/descendencia')
    .then(resposta => desc = resposta.data)
    .catch(erro => console.log('Erro ao carregar dados.'))

  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/3')
    .then(resposta => nivel3 = resposta.data)
    .catch(erro => console.log('Erro ao carregar dados.'))
  var result = []
  var count = 0
  for(i = 0; i < desc.length; i++) {
    for (j = 0; j < nivel3.length; j++) {
      var x = nivel3[j].split(".")[0] + "." + nivel3[j].split(".")[1]
      if (desc[i].codigo == x) {
        count++
        result.push(nivel3[j])
      }
    }
  }
  console.log("Count: " + count +"\nResult: "+result)
}
*/

// PARTE 2

router.get('/', function(req, res, next) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(resposta => res.render('index', {classes: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
    })
});


router.get('/classe/:id', function(req, res, next) {
  var dados = []
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.id)
    .then(resposta => dados = resposta.data[0])
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
  })
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.id + '/descendencia')
    .then(resposta => res.render('classe', {dados: dados, descendencia: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
  })
});

module.exports = router;
