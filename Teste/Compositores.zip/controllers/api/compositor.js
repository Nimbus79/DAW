var Compositor = require('../../models/compositor')


module.exports.listar = () => {
    return Compositor
        .find({},{_id:0, id:1, nome:1, dataNasc:1})
        .exec()
}


module.exports.consultar = cid => {
    return Compositor
        .findOne({id: cid})
        .exec()
}


module.exports.listarPeriodo = periodo => {
    return Compositor
        .find({periodo: periodo})
        .exec()
}


module.exports.listarPeriodoData = (periodo,data) => {
    return Compositor
        .find({dataNasc: {$gt: data}, periodo: periodo})
        .exec()
}