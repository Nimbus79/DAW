var express = require('express')
var router = express.Router()
var Compositor = require('../../controllers/api/compositor')

router.get('/', (req, res) => {
    if (req.query.data && req.query.periodo) {
        Compositor.listarPeriodoData(req.query.periodo, req.query.data)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
    }
    else if (req.query.periodo) {
        Compositor.listarPeriodo(req.query.periodo)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
    }
    else {
        Compositor.listar()
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
    }
})

router.get('/:id', (req, res) => {
    Compositor.consultar(req.params.id)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na consulta de um compositor.'))
})


module.exports = router